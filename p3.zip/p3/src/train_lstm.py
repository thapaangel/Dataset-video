"""Train an LSTM on saved landmark sequences.

Expected dataset layout:
  landmark_sequences/
    train/<label>/*.npy   # each .npy is a (T, F) array of landmarks per sequence
    val/<label>/*.npy

This script will:
 - load sequences, pad/truncate to a fixed length
 - build a simple BiLSTM classifier
 - train and save model to models/lstm_model.keras and label_map.json
"""
import json
from pathlib import Path
from typing import Tuple, List

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks


DATA_DIR = Path("landmark_sequences")
TRAIN_DIR = DATA_DIR / "train"
VAL_DIR = DATA_DIR / "val"
MODEL_OUT = Path("models/lstm_model.keras")
LABEL_MAP_OUT = Path("models/label_map_lstm.json")

SEQ_LEN = 50  # target sequence length (pad/truncate to this)
BATCH_SIZE = 64
EPOCHS = 40
LR = 1e-3


def load_sequences(folder: Path) -> Tuple[List[np.ndarray], List[str]]:
    X = []
    y = []
    if not folder.exists():
        return X, y
    for label_dir in sorted([d for d in folder.iterdir() if d.is_dir()]):
        label = label_dir.name
        for p in label_dir.glob("*.npy"):
            arr = np.load(p)
            if arr.ndim ==1:
                arr=arr.reshape(1,-1)
            X.append(arr)
            y.append(label)
    return X, y
    

def pad_truncate(seq: np.ndarray, target_len: int) -> np.ndarray:
    # seq shape: (T, F)
    if seq.shape[0] >= target_len:
        return seq[:target_len]
    else:
        pad = np.zeros((target_len - seq.shape[0], seq.shape[1]), dtype=seq.dtype)
        return np.vstack([seq, pad])


def prepare_data(X_list: List[np.ndarray], y_list: List[str], label_map: dict = None) -> Tuple[np.ndarray, np.ndarray, dict]:
    if label_map is None:
        labels = sorted(set(y_list))
        label_map = {lbl: idx for idx, lbl in enumerate(labels)}
    X = []
    for seq in X_list:
        X.append(pad_truncate(seq, SEQ_LEN))
    X = np.stack(X)
    y = np.array([label_map[l] for l in y_list], dtype=np.int32)
    return X, y, label_map


def build_model(input_shape: Tuple[int, int], num_classes: int):
    inp = layers.Input(shape=input_shape)
    x = layers.Masking(mask_value=0.0)(inp)
    x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(x)
    x = layers.Bidirectional(layers.LSTM(64))(x)
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(128, activation='relu')(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(num_classes, activation='softmax')(x)
    model = models.Model(inputs=inp, outputs=out)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=LR), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model


def main():
    X_train_list, y_train_list = load_sequences(TRAIN_DIR)
    X_val_list, y_val_list = load_sequences(VAL_DIR)

    if len(X_train_list) == 0:
        print(f"No training sequences found in {TRAIN_DIR}")
        return

    # build or read label map from existing saved map
    if LABEL_MAP_OUT.exists():
        label_map = json.loads(LABEL_MAP_OUT.read_text(encoding='utf-8'))
    else:
        label_map = None

    X_train, y_train, label_map = prepare_data(X_train_list, y_train_list, label_map)
    X_val, y_val, _ = prepare_data(X_val_list, y_val_list, label_map)

    num_classes = len(label_map)
    print(f"Train sequences: {X_train.shape}, Val sequences: {X_val.shape}, classes: {num_classes}")

    model = build_model((SEQ_LEN, X_train.shape[2]), num_classes)
    model.summary()

    cb = [
        callbacks.ModelCheckpoint(str(MODEL_OUT), save_best_only=True, monitor='val_accuracy'),
        callbacks.EarlyStopping(patience=7, restore_best_weights=True, monitor='val_accuracy')
    ]

    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val) if X_val.size else None,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=cb
    )

    # save label map
    LABEL_MAP_OUT.parent.mkdir(parents=True, exist_ok=True)
    LABEL_MAP_OUT.write_text(json.dumps(label_map, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved label map to', LABEL_MAP_OUT)

    print('Saving final model to', MODEL_OUT)
    model.save(MODEL_OUT)


if __name__ == '__main__':
    main()
