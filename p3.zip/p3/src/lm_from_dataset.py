import cv2
import mediapipe as mp
import numpy as np
import os

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7)

IMG_DIR = "datas/test"
SEQUENCE_DIR = "landmark_sequences/test"
os.makedirs(SEQUENCE_DIR, exist_ok=True)

for gesture in os.listdir(IMG_DIR):
    gesture_path = os.path.join(IMG_DIR, gesture)
    os.makedirs(os.path.join(SEQUENCE_DIR, gesture), exist_ok=True)
    for idx, img_file in enumerate(os.listdir(gesture_path)):
        img_path = os.path.join(gesture_path, img_file)
        img = cv2.imread(img_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        result = hands.process(img_rgb)
        if result.multi_hand_landmarks:
            print(f"HAND DETECTED")
            lm = result.multi_hand_landmarks[0] # process first detected hand
            landmarks = np.array([[p.x, p.y, p.z] for p in lm.landmark]).flatten()
            # save as npy
            np.save(os.path.join(SEQUENCE_DIR, gesture, f"{idx}.npy"), landmarks)
        else:
            print(f"Hand not detected in {img_path}")
hands.close()
