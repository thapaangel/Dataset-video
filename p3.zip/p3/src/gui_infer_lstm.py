import json
from collections import deque
from pathlib import Path
import warnings
warnings.filterwarnings("ignore", message="SymbolDatabase.GetPrototype() is deprecated")

import cv2
import numpy as np
import tkinter as tk
from tkinter import ttk, scrolledtext
from PIL import Image, ImageTk
import time

from hand_landmarks import HandLandmarksDetector
try:
    from tensorflow.keras.models import load_model
except Exception:
    try:
        from keras.models import load_model
    except Exception:
        def load_model(path):
            raise ImportError("Cannot import load_model from tensorflow.keras or keras. Install tensorflow or keras.")

# Config
MODEL_PATH = Path("model/lstm_model.keras")
LABEL_MAP_PATH = Path("model/label_map_lstm.json")
SEQ_LEN = 50
CONF_THRESH = 0.98
FPS_MS = 30


def _to_fixed_vector(v, feature_dim):
    arr = np.asarray(v, dtype=float).ravel()
    if arr.size == feature_dim:
        return arr
    if arr.size > feature_dim:
        return arr[:feature_dim]
    pad = np.zeros(feature_dim - arr.size, dtype=float)
    return np.concatenate([arr, pad])


def landmarks_to_bbox(flattened, frame_w, frame_h):
    if flattened is None:
        return None
    arr = np.asarray(flattened, dtype=float).ravel()
    if arr.size < (33 + 21 + 21) * 3:
        try:
            coords = arr.reshape(-1, 3)
        except Exception:
            return None
    else:
        pose_count = 33 * 3
        hand_count = 21 * 3
        left = arr[pose_count:pose_count + hand_count].reshape(21, 3)
        right = arr[pose_count + hand_count:pose_count + 2 * hand_count].reshape(21, 3)
        left_valid = left[:, :2][np.any(left[:, :2] != 0, axis=1)]
        right_valid = right[:, :2][np.any(right[:, :2] != 0, axis=1)]
        chosen = None
        if left_valid.size and right_valid.size:
            lx_min, ly_min = left_valid.min(axis=0)
            lx_max, ly_max = left_valid.max(axis=0)
            rx_min, ry_min = right_valid.min(axis=0)
            rx_max, ry_max = right_valid.max(axis=0)
            if (lx_max - lx_min) * (ly_max - ly_min) >= (rx_max - rx_min) * (ry_max - ry_min):
                chosen = left_valid
            else:
                chosen = right_valid
        elif left_valid.size:
            chosen = left_valid
        elif right_valid.size:
            chosen = right_valid
        else:
            chosen = None

        if chosen is None:
            return None

        xs = np.clip((chosen[:, 0] * frame_w), 0, frame_w - 1)
        ys = np.clip((chosen[:, 1] * frame_h), 0, frame_h - 1)
        x1, x2 = int(xs.min()), int(xs.max())
        y1, y2 = int(ys.min()), int(ys.max())
        pad = int(0.08 * max(x2 - x1 + 1, y2 - y1 + 1)) + 6
        x1 = max(0, x1 - pad)
        y1 = max(0, y1 - pad)
        x2 = min(frame_w - 1, x2 + pad)
        y2 = min(frame_h - 1, y2 + pad)
        return (x1, y1, x2, y2)

    coords = coords[:, :2]
    valid = coords[np.any(coords != 0, axis=1)]
    if valid.size == 0:
        return None
    xs = np.clip((valid[:, 0] * frame_w), 0, frame_w - 1)
    ys = np.clip((valid[:, 1] * frame_h), 0, frame_h - 1)
    x1, x2 = int(xs.min()), int(xs.max())
    y1, y2 = int(ys.min()), int(ys.max())
    pad = int(0.08 * max(x2 - x1 + 1, y2 - y1 + 1)) + 6
    x1 = max(0, x1 - pad)
    y1 = max(0, y1 - pad)
    x2 = min(frame_w - 1, x2 + pad)
    y2 = min(frame_h - 1, y2 + pad)
    return (x1, y1, x2, y2)


class GuiApp:
    def __init__(self, root):
        self.root = root
        root.title('ASL Live')
        style = ttk.Style(root)
        style.theme_use('clam')

        self.canvas = tk.Canvas(root, width=800, height=560, bg='black')
        self.canvas.grid(row=0, column=0, padx=6, pady=6)

        ctrl = ttk.Frame(root)
        ctrl.grid(row=0, column=1, sticky='ns', padx=6, pady=6)
        self.start_btn = ttk.Button(ctrl, text='Start Capture', command=self.start_capture)
        self.start_btn.pack(fill='x', pady=4)
        self.stop_btn = ttk.Button(ctrl, text='Stop Capture', command=self.stop_capture)
        self.stop_btn.pack(fill='x', pady=4)
        self.quit_btn = ttk.Button(ctrl, text='Quit', command=self.quit)
        self.quit_btn.pack(fill='x', pady=4)

        ttk.Label(ctrl, text='Captured:').pack(anchor='w', pady=(8,0))
        self.textbox = scrolledtext.ScrolledText(ctrl, width=20, height=12, font=('Consolas', 14))
        self.textbox.pack(fill='both', expand=True)

        self.status = ttk.Label(root, text='Loading model...', anchor='w')
        self.status.grid(row=1, column=0, columnspan=2, sticky='ew', padx=6, pady=(0,6))

        if not MODEL_PATH.exists():
            raise FileNotFoundError('Model not found: ' + str(MODEL_PATH))
        self.model = load_model(str(MODEL_PATH))
        label_map = {}
        if LABEL_MAP_PATH.exists():
            try:
                label_map = json.loads(LABEL_MAP_PATH.read_text(encoding='utf-8'))
            except Exception:
                label_map = {}
        self.label_map_inv = {int(v): k for k, v in (label_map or {}).items()} if label_map else None

        try:
            self.feature_dim = int(self.model.input_shape[-1])
        except Exception:
            self.feature_dim = (33 + 21 + 21) * 3

        self.seq_buf = deque(maxlen=SEQ_LEN)
        self.capturing = False
        self.last_append_time = 0.0
        # highlight box until this timestamp (seconds since epoch). When a character is appended,
        # we set this to now + HIGHLIGHT_DURATION so the box turns green briefly.
        self.highlight_until = 0.0
        self.HIGHLIGHT_DURATION = 1.5

        self.detector = HandLandmarksDetector()
        self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            raise RuntimeError('Cannot open camera')

        self.photo = None
        self.status.config(text='Ready')
        self.update_loop()

    def start_capture(self):
        self.capturing = True
        self.status.config(text='Capturing: ON')

    def stop_capture(self):
        self.capturing = False
        self.status.config(text='Capturing: OFF')

    def quit(self):
        self.cap.release()
        self.detector.close()
        self.root.quit()

    def update_loop(self):
        ret, frame = self.cap.read()
        if not ret:
            self.root.after(FPS_MS, self.update_loop)
            return
        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]

        annotated, landmarks = self.detector.process(frame)
        bbox = landmarks_to_bbox(landmarks, w, h)
        label_text = None
        conf = 0.0

        if landmarks is None:
            fixed = np.zeros(self.feature_dim, dtype=float)
        else:
            fixed = _to_fixed_vector(landmarks, self.feature_dim)

        self.seq_buf.append(fixed)

        if len(self.seq_buf) == SEQ_LEN:
            seq = np.stack(list(self.seq_buf)).astype(np.float32)
            inp = np.expand_dims(seq, axis=0)
            try:
                preds = self.model.predict(inp, verbose=0)
                idx = int(np.argmax(preds[0]))
                conf = float(np.max(preds[0]))
                label_text = self.label_map_inv.get(idx, str(idx)) if self.label_map_inv else str(idx)
            except Exception:
                label_text = None
                conf = 0.0

            if label_text and conf >= CONF_THRESH and self.capturing:
                now = time.time()
                # append at most once every 3 seconds
                if now - self.last_append_time >= 3.0:
                    self.textbox.insert(tk.END, str(label_text))
                    self.textbox.see(tk.END)
                    self.last_append_time = now
                    # set highlight so bbox turns green briefly
                    self.highlight_until = now + self.HIGHLIGHT_DURATION

        vis = annotated.copy()
        if bbox:
            x1, y1, x2, y2 = bbox
            # choose color: green if within highlight window, otherwise default bluish
            now_draw = time.time()
            if now_draw < getattr(self, 'highlight_until', 0.0):
                box_color = (20, 220, 60)  # green-ish BGR
                fill_color = (20, 220, 60)
            else:
                box_color = (20, 160, 255)
                fill_color = (20, 160, 255)
            cv2.rectangle(vis, (x1, y1), (x2, y2), box_color, 3, cv2.LINE_AA)
            lbl = f"{label_text or '-'} {conf:.2f}"
            (tw, th), _ = cv2.getTextSize(lbl, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
            bx1 = x1
            by1 = max(0, y1 - th - 12)
            bx2 = min(w - 1, x1 + tw + 12)
            by2 = y1
            cv2.rectangle(vis, (bx1, by1), (bx2, by2), fill_color, -1)
            cv2.putText(vis, lbl, (bx1 + 6, by2 - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA)
        else:
            cv2.putText(vis, 'No hand', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (200, 200, 200), 2, cv2.LINE_AA)

        vis_rgb = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(vis_rgb)
        canvas_w = self.canvas.winfo_width() or 800
        canvas_h = self.canvas.winfo_height() or 560
        img = img.resize((canvas_w, canvas_h), Image.BILINEAR)
        self.photo = ImageTk.PhotoImage(img)
        self.canvas.create_image(0, 0, image=self.photo, anchor='nw')

        self.root.after(FPS_MS, self.update_loop)


if __name__ == '__main__':
    root = tk.Tk()
    root.geometry('1100x640')
    app = GuiApp(root)
    root.mainloop()
