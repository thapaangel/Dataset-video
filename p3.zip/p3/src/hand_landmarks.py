import cv2
import mediapipe as mp

class HandLandmarksDetector:
    # Initialize the hand landmarks detector
    # min_detection_confidence/min_tracking_confidence: 0.0 to 1.0 (0.5 is default)
    # static_image_mode: False for video, True for images 
    def __init__(self, max_hands=2, min_detection_confidence=0.5, min_tracking_confidence=0.5):
        self._mp_hands = mp.solutions.hands
        self._draw = mp.solutions.drawing_utils
        self._hands = self._mp_hands.Hands(
            static_image_mode=False
        )

    def process(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) # mediapipe needs RGB, openCV ko default bgr hunxa
        res = self._hands.process(rgb) 
        out = frame.copy() 
        hands = []
        if res.multi_hand_landmarks: 
            for hl in res.multi_hand_landmarks:
                self._draw.draw_landmarks(out, hl, self._mp_hands.HAND_CONNECTIONS)
                hands.append([(lm.x, lm.y, lm.z) for lm in hl.landmark])
        return out, hands

    def close(self):
        self._hands.close()