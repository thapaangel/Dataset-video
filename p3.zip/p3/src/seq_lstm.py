import numpy as np
import os
from tensorflow.keras.utils import to_categorical

seq_len = 30  # number of frames per sequence
data_dir = "landmark_sequences/val"  # directory with gesture subfolders

X, y = [], []
gesture_list = sorted(os.listdir(data_dir))
label_map = {g:i for i,g in enumerate(gesture_list)}

for gesture in gesture_list:
    files = sorted(os.listdir(os.path.join(data_dir, gesture)))
    # form sequences
    for i in range(0, len(files) - seq_len + 1, seq_len):  # sliding window
        seq_files = files[i:i+seq_len]
        seq = []    
        for f in seq_files:
            landmarks = np.load(os.path.join(data_dir, gesture, f))
            seq.append(landmarks)
        if len(seq) == seq_len:
            X.append(seq)
            y.append(label_map[gesture])

X = np.array(X)  # shape: (num_sequences, seq_len, 63)
y = to_categorical(y)

np.savez("lstm_data.npz", X=X, y=y)
print("Saved X and y to lstm_data.npz")
