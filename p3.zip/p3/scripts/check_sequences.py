"""Check .npy sequence files under landmark_sequences for consistent shapes.

Run with the project's venv python to get a report of sequence counts and any malformed files.
"""
import numpy as np
from pathlib import Path

root = Path('landmark_sequences')
for split in ['train', 'val', 'test']:
    p = root / split
    if not p.exists():
        print(f'{split}: missing')
        continue
    print('---', split, '---')
    total = 0
    bad = []
    shapes_count = {}
    for label_dir in sorted([d for d in p.iterdir() if d.is_dir()]):
        for f in label_dir.glob('*.npy'):
            total += 1
            try:
                a = np.load(f)
                s = a.shape
                shapes_count[s] = shapes_count.get(s, 0) + 1
                if a.ndim != 2:
                    bad.append((str(f), s))
            except Exception as e:
                bad.append((str(f), 'load_error:' + str(e)))
    print('total files:', total)
    items = list(shapes_count.items())
    items.sort(key=lambda kv: -kv[1])
    print('shape counts (top 10):')
    for s, c in items[:10]:
        print(' ', s, c)
    if bad:
        print('bad files (up to 50):')
        for b in bad[:50]:
            print(' ', b)
    else:
        print('no bad files')
